import {build} from 'esbuild';
import {cp,mkdir} from 'node:fs/promises';
await mkdir('dist',{recursive:true});
await cp('public','dist',{recursive:true});
await build({entryPoints:['main.tsx'],bundle:true,jsx:'automatic',format:'esm',minify:true,outfile:'dist/site.js'});
