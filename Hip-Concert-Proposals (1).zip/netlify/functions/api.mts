import {getStore} from '@netlify/blobs';
import {getUser} from '@netlify/identity';
import {artists} from '../../lib/artists';
const json=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'private, no-store'}});
export const config={path:['/api/me','/api/team','/api/view','/api/proposals']};
export default async function api(req:Request){
 const url=new URL(req.url), route=url.pathname, id=url.searchParams.get('id');
 const proposals=getStore({name:'concert-proposals',consistency:'strong'});
 if(req.method==='GET' && id && /^[a-f0-9-]{36}$/.test(id) && route==='/api/view'){
 const p=await proposals.get(id,{type:'json'});return p?json(p):json({error:'Unavailable'},404);}
 const user=await getUser();if(!user?.email)return json({error:'Sign in required'},401);
 const email=user.email.toLowerCase(),owner=email==='nellie@hipentertainment.com';
 const members=getStore({name:'concert-staff',consistency:'strong'});
 if(!owner && !await members.get(email))return json({error:'Team access required'},403);
 if(req.method==='POST' && req.headers.get('origin')!==url.origin)return json({error:'Invalid origin'},403);
 if(route==='/api/me')return json({name:email,email,owner});
 if(route==='/api/team'){
 if(!owner)return json({error:'Owner access required'},403);
 if(req.method==='POST'){const b=await req.json(),key=String(b.email).trim().toLowerCase();
 if(!/^[^\s/@]+@[^\s/@]+\.[^\s/@]+$/.test(key))return json({error:'Enter a valid email'},400);
 if(b.remove)await members.delete(key);else await members.set(key,'approved');}
 return json((await members.list()).blobs.map(x=>x.key));}
 if(route!=='/api/proposals')return json({error:'Unavailable'},404);
 if(req.method==='GET'){
 if(id)return json(await proposals.get(id,{type:'json'}));
 const list=await proposals.list();return json((await Promise.all(list.blobs.map(async x=>{const p=await proposals.get(x.key,{type:'json'});return {id:p.id,title:p.title,created:p.created,creatorName:p.contact,count:p.artists.length};}))).sort((a,b)=>b.created.localeCompare(a.created)));}
 if(req.method!=='POST')return json({error:'Unsupported method'},405);
 const b=await req.json();if(!Array.isArray(b.selected)||!b.selected.length||b.selected.length>artists.length||new Set(b.selected).size!==b.selected.length||['title','intro','dates','pricing'].some(k=>typeof b[k]!=='string'||b[k].length>5000)||!b.title.trim())return json({error:'Check proposal fields'},400);
 const lineup=b.selected.map(slug=>artists.find(a=>a.slug===slug));if(lineup.some(a=>!a))return json({error:'Unknown artist'},400);
 const key=crypto.randomUUID();await proposals.setJSON(key,{id:key,title:b.title,intro:b.intro,dates:b.dates,pricing:b.pricing,feature:!!b.feature,social:!!b.social,production:!!b.production,artists:lineup,contact:email,created:new Date().toISOString()});return json({id:key},201);
}
