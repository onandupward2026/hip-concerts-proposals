import {createRoot} from 'react-dom/client';
import {useState} from 'react';
import {login,signup,logout,handleAuthCallback} from '@netlify/identity';
import Home from './app/page';
import Editor from './app/team/editor';
import ArtistPage from './components/ArtistPage';
import {artists} from './lib/artists';
import './app/globals.css';
const root=createRoot(document.getElementById('root')!);
function Login(){
 const [message,setMessage]=useState('');
 return <main className="editor section"><h1>Team sign-in</h1><form className="editorfields" onSubmit={async e=>{
 e.preventDefault();const f=new FormData(e.currentTarget);
 try{const email=String(f.get('email')),password=String(f.get('password'));
 if((e.nativeEvent as SubmitEvent).submitter?.id==='register'){await signup(email,password);setMessage('Check your email to confirm your account.');}
 else{await login(email,password);location.assign('/team');}}catch{setMessage('Could not complete sign-in. Check your email and password or contact your Hip team administrator.');}
 }}><label>Work email<input required name="email" type="email"/></label><label>Password<input required name="password" type="password"/></label><button className="button dark">Sign in</button><button id="register">Create account</button></form><p role="status">{message}</p></main>;
}
async function open(){
 if(/(?:confirmation|invite|recovery|access)_token=/.test(location.hash)){await handleAuthCallback();location.replace('/team');return;}
 const parts=location.pathname.split('/').filter(Boolean);
 if(parts[0]==='team'){const r=await fetch('/api/me');if(r.status===401)return root.render(<Login/>);
 if(!r.ok)return root.render(<main className="section"><p>Your account needs team access. Contact your Hip administrator.</p><button onClick={async()=>{await logout();location.reload()}}>Sign out</button></main>);
 return root.render(<><Editor {...await r.json()}/><button onClick={async()=>{await logout();location.reload()}}>Sign out</button></>);}
 let proposal;let path=parts;
 if(parts[0]==='p'){const r=await fetch('/api/view?id='+encodeURIComponent(parts[1]||''));if(!r.ok)throw Error('Proposal unavailable. Please contact your Hip representative.');proposal=await r.json();path=parts.slice(2);}
 if(path[0]==='artists'){const artist=(proposal?.artists||artists).find(a=>a.slug===path[1]);if(!artist)throw Error('Artist unavailable.');return root.render(<ArtistPage artist={artist} back={proposal?'/p/'+proposal.id+'/':'/'} contact={proposal?.contact}/>);}
 root.render(<Home proposal={proposal}/>);
}
open().catch(e=>root.render(<main className="section"><p>{e.message}</p></main>));
