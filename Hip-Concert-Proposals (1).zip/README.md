# Hip Entertainment proposal site
Use Node 22 or newer. In this directory run npm ci and npm run build.
Sign into the Netlify CLI using npx netlify-cli login, link this directory to the existing hip-concert-proposals project using npx netlify-cli link, and deploy with npx netlify-cli deploy --prod --build.
Enable Netlify Identity in the project's Identity settings. Enable email confirmation and email/password signup. The application restricts staff access by verified email. The owner is nellie@hipentertainment.com.
Open /team, create your account with your work email, confirm it, and sign in. The owner can add teammates under Team access. Each teammate registers and confirms their approved address.
Recipients can view a saved /p/ link without an account, including any pricing shown there. Existing ChatGPT-hosted proposals keep their original links.
